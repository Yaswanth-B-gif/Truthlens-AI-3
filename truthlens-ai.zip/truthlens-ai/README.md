# TruthLens AI: Data-Driven Detection of False Information & Trustworthy Content

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110%2B-009688.svg)](https://fastapi.tiangolo.com/)
[![React 18](https://img.shields.io/badge/React-18.3-61DAFB.svg)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.7-3178C6.svg)](https://www.typescriptlang.org/)
[![TailwindCSS](https://img.shields.io/badge/TailwindCSS-3.4-38BDF8.svg)](https://tailwindcss.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> **“Detect False Information. Discover What You Can Trust.”**
> An AI-powered data-driven web application for identifying misleading, false, and trustworthy digital content on digital platforms.

---

## 🌟 Key Features

1. **Multimodal Ingestion**:
   - **Text Snippets**: Direct paste of viral posts, speeches, articles, or transcripts.
   - **Website URLs**: Automatic real-time web scraping and body parsing.
   - **Documents**: File upload and text extraction from **PDF**, **DOCX**, and **TXT**.
   - **Images**: Screenshot and graphic ingestion with OCR heuristics.

2. **Modular NLP & Verification Pipeline**:
   - **Propositional Claim Decomposition**: Breaks complex paragraphs into individual factual assertions.
   - **Claim-by-Claim Verification**: Labels claims as `Supported`, `Contradicted`, `Needs Verification`, or `Partially Supported`.
   - **Linguistic & Sensationalism Forensics**: Quantifies emotional triggers (anger, fear, urgency), clickbait scores, and hyperbole.
   - **Source Credibility Index**: Evaluates domain authority, bylines, academic TLDs, and DOI references.

3. **Transparent & Configurable Trust Score**:
   - Computes a mathematical composite Trust Score (0–100):
     `TrustScore = w1·C_src + w2·E_str + w3·C_clm + w4·A_cross + w5·L_clean + w6·X_ctx`
   - Configurable parameter weights for academic experimentation.

4. **Zero-Config Demo Mode**:
   - Preloaded with 4 benchmark scenarios: *Trustworthy Science News*, *Misleading Health Remedy*, *False 5G Conspiracy*, and *Sensational Clickbait*.
   - **Works 100% locally out-of-the-box without requiring any external API keys**, with optional live Google Gemini / LLM expansion hooks.

5. **Analytics Dashboard & Audit History**:
   - Real-time Recharts visualizations: Trust score distribution, classification breakdown, recent audits, search and filters.

---

## 📁 Project Structure

```
truthlens-ai/
├── backend/
│   ├── app/
│   │   ├── ai_engine/       # NLP, Claim Extraction, Scorer, Evidence Matcher
│   │   ├── api/             # FastAPI REST endpoints (auth, analyze, dashboard, history)
│   │   ├── core/            # Config, settings, JWT security
│   │   ├── db/              # SQLAlchemy models, schemas, and session
│   │   └── main.py          # Application entrypoint & pre-seeding
│   ├── tests/               # Pytest automated test suite
│   └── requirements.txt     # Backend Python dependencies
├── frontend/
│   ├── src/
│   │   ├── components/      # ScoreGauge, BrandLogo, Navbar, Footer, AuthModal
│   │   ├── context/         # AuthContext, ThemeContext
│   │   ├── pages/           # LandingPage, AnalyzePage, ResultsPage, Dashboard, History, Research
│   │   ├── services/        # Centralized Axios API client
│   │   └── types/           # TypeScript interfaces
│   ├── package.json
│   └── vite.config.ts
├── .env.example
└── README.md
```

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- **Python 3.10+** (Tested on Python 3.14)
- **Node.js 18+** and **npm**

### 2. Backend Setup
```bash
cd backend
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload --port 8000
```
*API Swagger Documentation will be available at http://localhost:8000/docs.*

### 3. Frontend Setup
```bash
cd frontend
npm.cmd install
npm.cmd run dev
```
*Open http://localhost:3000 in your browser.*

---

## 🧪 Running Automated Tests

Run the full backend test suite covering NLP modules, claim extractors, trust scoring math, auth, and API endpoints:
```bash
cd backend
python -m pytest tests/ -v
```

---

## 🛡️ AI Safety & Disclaimer

TruthLens AI provides automated assessments based on algorithmic heuristics and indexed knowledge corpus data. It should not be considered an absolute fact-checking authority. Critical decisions should always be verified against primary sources.

---

## 📄 License

Distributed under the MIT License.