import axios from 'axios';
import { AnalysisResult, AnalysisSummary, DashboardStats, User } from '../types';

const API_BASE = '/api';

const apiClient = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Attach token interceptor
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('truthlens_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const api = {
  auth: {
    register: async (data: { name: string; email: string; password: string }) => {
      const res = await apiClient.post<{ access_token: string; token_type: string; user: User }>('/auth/register', data);
      return res.data;
    },
    login: async (data: { email: string; password: string }) => {
      const res = await apiClient.post<{ access_token: string; token_type: string; user: User }>('/auth/login', data);
      return res.data;
    },
    getMe: async () => {
      const res = await apiClient.get<User>('/auth/me');
      return res.data;
    },
  },
  analyze: {
    text: async (text: string, title?: string, custom_weights?: Record<string, number>) => {
      const res = await apiClient.post<AnalysisResult>('/analyze/text', { text, title, custom_weights });
      return res.data;
    },
    url: async (url: string, custom_weights?: Record<string, number>) => {
      const res = await apiClient.post<AnalysisResult>('/analyze/url', { url, custom_weights });
      return res.data;
    },
    file: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      const res = await apiClient.post<AnalysisResult>('/analyze/file', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return res.data;
    },
    image: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      const res = await apiClient.post<AnalysisResult>('/analyze/image', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return res.data;
    },
    demo: async (scenario: string) => {
      const res = await apiClient.post<AnalysisResult>('/analyze/demo', { scenario });
      return res.data;
    },
  },
  history: {
    getAll: async (params?: { classification?: string; content_type?: string; query?: string }) => {
      const res = await apiClient.get<AnalysisSummary[]>('/history', { params });
      return res.data;
    },
    getById: async (id: string) => {
      const res = await apiClient.get<AnalysisResult>(`/history/${id}`);
      return res.data;
    },
    delete: async (id: string) => {
      const res = await apiClient.delete(`/history/${id}`);
      return res.data;
    },
    clearAll: async () => {
      const res = await apiClient.delete('/history/clear/all');
      return res.data;
    },
  },
  dashboard: {
    getMetrics: async () => {
      const res = await apiClient.get<DashboardStats>('/dashboard');
      return res.data;
    },
  },
  feedback: {
    submit: async (data: { analysis_id: string; rating: number; comment?: string }) => {
      const res = await apiClient.post('/feedback', data);
      return res.data;
    },
  },
};
