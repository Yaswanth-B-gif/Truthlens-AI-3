import React, { useEffect, useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from 'recharts';
import { 
  ShieldCheck, 
  AlertTriangle, 
  XCircle, 
  CheckCircle2, 
  HelpCircle, 
  BarChart3, 
  Sparkles, 
  ArrowUpRight, 
  Filter, 
  Loader2, 
  RefreshCw 
} from 'lucide-react';
import { DashboardStats, AnalysisSummary } from '../types';
import { api } from '../services/api';

interface DashboardPageProps {
  onViewAnalysis: (id: string) => void;
  onNavigate: (page: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onViewAnalysis, onNavigate }) => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState('All');

  const loadDashboard = async () => {
    setLoading(true);
    try {
      const data = await api.dashboard.getMetrics();
      setStats(data);
    } catch (e) {
      console.error('Failed to load dashboard metrics:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, []);

  const filteredAnalyses = stats?.recent_analyses.filter((item) => {
    if (selectedFilter === 'All') return true;
    if (selectedFilter === 'Trustworthy') return item.trust_score >= 60;
    if (selectedFilter === 'Misleading') return item.trust_score >= 20 && item.trust_score < 40;
    if (selectedFilter === 'False') return item.trust_score < 20;
    if (selectedFilter === 'Needs Verification') return item.trust_score >= 40 && item.trust_score < 60;
    return true;
  }) || [];

  const pieColors = ['#10B981', '#06B6D4', '#F59E0B', '#F97316', '#EF4444'];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8 animate-fade-in">
      {/* Top title & refresh toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-xs font-semibold text-cyan-300">
            <BarChart3 className="w-3.5 h-3.5 text-cyan-400" />
            Verification Intelligence & Trends
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Platform Analytics Dashboard</h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadDashboard}
            disabled={loading}
            className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-700 transition flex items-center gap-1.5"
            title="Refresh Metrics"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Refresh Data</span>
          </button>

          <button
            onClick={() => onNavigate('analyze')}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:opacity-95 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 flex items-center gap-1.5 transition"
          >
            <Sparkles className="w-4 h-4" />
            <span>New Analysis</span>
          </button>
        </div>
      </div>

      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center space-y-3">
          <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          <p className="text-xs text-slate-400">Aggregating real-time trust metrics...</p>
        </div>
      ) : stats ? (
        <>
          {/* KPI CARDS GRID */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Analyses</div>
              <div className="text-3xl font-extrabold text-white font-mono">{stats.total_analyses}</div>
              <p className="text-[11px] text-slate-500">Processed across text, URL, & docs</p>
            </div>

            <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Trustworthy Content
              </div>
              <div className="text-3xl font-extrabold text-emerald-400 font-mono">{stats.trustworthy_count}</div>
              <p className="text-[11px] text-slate-500">Score &ge; 60/100 verified rate</p>
            </div>

            <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 text-rose-400">
                <XCircle className="w-3.5 h-3.5 text-rose-400" />
                False / Misleading
              </div>
              <div className="text-3xl font-extrabold text-rose-400 font-mono">
                {stats.false_count + stats.misleading_count}
              </div>
              <p className="text-[11px] text-slate-500">Flagged for factual contradictions</p>
            </div>

            <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider text-cyan-400">
                Average Trust Index
              </div>
              <div className="text-3xl font-extrabold text-cyan-400 font-mono">{stats.average_trust_score}/100</div>
              <p className="text-[11px] text-slate-500">Mean cross-platform score</p>
            </div>
          </div>

          {/* CHARTS GRID */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Chart 1: Trust Score Distribution */}
            <div className="lg:col-span-7 p-6 rounded-3xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Trust Score Distribution (0–100)</h3>
                  <p className="text-xs text-slate-400">Frequency of content analyses across score buckets</p>
                </div>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stats.score_distribution} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <XAxis dataKey="range" stroke="#64748b" fontSize={11} />
                    <YAxis stroke="#64748b" fontSize={11} allowDecimals={false} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                      itemStyle={{ color: '#38bdf8' }}
                    />
                    <Bar dataKey="count" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Classification Donut */}
            <div className="lg:col-span-5 p-6 rounded-3xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white">Classification Ratio</h3>
                <p className="text-xs text-slate-400">Veracity distribution breakdown</p>
              </div>

              <div className="h-64 w-full flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stats.classification_distribution}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={80}
                      paddingAngle={3}
                    >
                      {stats.classification_distribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color || pieColors[index % pieColors.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* RECENT ANALYSES WITH FILTERS */}
          <div className="p-6 sm:p-8 rounded-3xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-white">Recent Analyses</h3>
                <p className="text-xs text-slate-400">Inspections logged across active sessions</p>
              </div>

              {/* Filter Tabs */}
              <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs font-semibold">
                {['All', 'Trustworthy', 'Needs Verification', 'Misleading', 'False'].map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setSelectedFilter(filter)}
                    className={`px-3 py-1 rounded-lg transition ${
                      selectedFilter === filter
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>

            {/* List */}
            <div className="space-y-3">
              {filteredAnalyses.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs">
                  No records match the selected filter.
                </div>
              ) : (
                filteredAnalyses.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => onViewAnalysis(item.id)}
                    className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 hover:bg-slate-950 transition cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
                  >
                    <div className="space-y-1 truncate">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                          {item.content_type}
                        </span>
                        <span className="text-xs text-slate-500">
                          {new Date(item.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-200 group-hover:text-cyan-300 transition truncate max-w-xl">
                        {item.content_title || 'Content Inspection'}
                      </h4>
                    </div>

                    <div className="flex items-center gap-4 flex-shrink-0">
                      <div className="text-right">
                        <div className={`text-sm font-extrabold font-mono ${
                          item.trust_score >= 80 ? 'text-emerald-400' :
                          item.trust_score >= 60 ? 'text-cyan-400' :
                          item.trust_score >= 40 ? 'text-amber-400' :
                          item.trust_score >= 20 ? 'text-orange-400' : 'text-rose-500'
                        }`}>
                          {Math.round(item.trust_score)}/100
                        </div>
                        <div className="text-[10px] text-slate-400 font-medium">
                          {item.classification}
                        </div>
                      </div>

                      <button
                        onClick={(e) => { e.stopPropagation(); onViewAnalysis(item.id); }}
                        className="p-2 rounded-lg bg-slate-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 transition"
                      >
                        <ArrowUpRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
};
