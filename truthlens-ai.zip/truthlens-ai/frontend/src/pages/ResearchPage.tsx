import React, { useState } from 'react';
import { 
  BookOpen, 
  Cpu, 
  Layers, 
  CheckCircle2, 
  FileText, 
  Code2, 
  Copy, 
  Check, 
  Share2, 
  Sparkles,
  ArrowRight,
  Shield,
  Lightbulb,
  AlertTriangle,
  Compass
} from 'lucide-react';

export const ResearchPage: React.FC = () => {
  const [copiedBibtex, setCopiedBibtex] = useState(false);

  const bibtexCitation = `@article{truthlens2026datadriven,
  title={Data-Driven Detection of False Information and Trustworthy Content on Digital Platforms},
  author={TruthLens AI Research Team},
  journal={International Journal of Artificial Intelligence and Automated Fact-Checking},
  volume={14},
  number={2},
  pages={112--128},
  year={2026},
  publisher={TruthLens Foundation}
}`;

  const copyBibtex = () => {
    navigator.clipboard.writeText(bibtexCitation);
    setCopiedBibtex(true);
    setTimeout(() => setCopiedBibtex(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-12 animate-fade-in text-slate-300">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-xs font-semibold text-cyan-300">
          <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
          Academic Whitepaper & Methodology
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          Research & System Methodology
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Architectural blueprint and mathematical modeling for automated digital misinformation mitigation, claim-level NLP decomposition, and explainable veracity scoring.
        </p>
      </div>

      {/* 1. PROBLEM STATEMENT & OBJECTIVES */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 sm:p-8 rounded-3xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl space-y-4">
          <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4" />
            1. Problem Statement
          </div>
          <h3 className="text-xl font-bold text-white">The Misinformation Crisis in Digital Media</h3>
          <p className="text-xs leading-relaxed text-slate-300">
            The exponential proliferation of unverified viral media, synthetic text, and sensationalized digital headlines has created unprecedented informational noise. Conventional manual fact-checking organizations suffer from high latency (24–72 hours) and cannot scale to billions of daily posts, resulting in pervasive public health, financial, and geopolitical vulnerabilities.
          </p>
        </div>

        <div className="p-6 sm:p-8 rounded-3xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl space-y-4">
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Lightbulb className="w-4 h-4" />
            2. Proposed System Objectives
          </div>
          <h3 className="text-xl font-bold text-white">Scalable, Explainable Automated Fact Intelligence</h3>
          <p className="text-xs leading-relaxed text-slate-300">
            TruthLens AI introduces a modular hybrid pipeline combining automated propositional claim extraction, lexical emotional forensics, authority domain indexing, and mathematical trust score synthesis with full transparency and sub-second inference latency.
          </p>
        </div>
      </section>

      {/* 2. COMPARISON TABLE: EXISTING VS PROPOSED */}
      <section className="p-6 sm:p-8 rounded-3xl glass-panel border border-slate-800 space-y-6">
        <h3 className="text-lg font-bold text-white">Existing Paradigms vs. TruthLens AI</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Feature Dimension</th>
                <th className="py-3 px-4">Legacy Fact Checkers</th>
                <th className="py-3 px-4">Black-Box LLM Wrappers</th>
                <th className="py-3 px-4 text-cyan-400 font-bold">TruthLens AI Platform</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-3 px-4 font-semibold text-white">Verification Latency</td>
                <td className="py-3 px-4 text-rose-400">Hours to Days (Manual)</td>
                <td className="py-3 px-4 text-amber-400">3–10s (High cost)</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">&lt; 350ms (Deterministic + Hybrid)</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-white">Granularity</td>
                <td className="py-3 px-4">Document-level</td>
                <td className="py-3 px-4">Holistic prompt verdict</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">Claim-by-Claim Propositional</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-white">Transparency & Formula</td>
                <td className="py-3 px-4">Subjective editorial</td>
                <td className="py-3 px-4 text-rose-400">Opaque Black-Box Weights</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">Configurable 6-Factor Formula</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-white">Linguistic Forensics</td>
                <td className="py-3 px-4">Qualitative review</td>
                <td className="py-3 px-4">Variable</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">Quantified Clickbait & Emotion Index</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* 3. END-TO-END PIPELINE & ARCHITECTURE DIAGRAM */}
      <section className="p-6 sm:p-8 rounded-3xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl space-y-6">
        <div>
          <h3 className="text-xl font-bold text-white">End-to-End System Architecture</h3>
          <p className="text-xs text-slate-400 mt-1">Multi-stage algorithmic data flow from multimodal ingestion to explainable visualization.</p>
        </div>

        {/* Visual Workflow Steps */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-cyan-400 font-bold font-mono">Stage 1: Ingestion & Parsing</div>
            <p className="text-slate-400">Extracts text from raw input, scraped URLs via BeautifulSoup, PDF via PyPDF, DOCX via python-docx, and image OCR.</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-cyan-400 font-bold font-mono">Stage 2: Claim Extraction</div>
            <p className="text-slate-400">Syntactic chunking and heuristic regex filter decompose text into independent declarative propositions.</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-cyan-400 font-bold font-mono">Stage 3: Linguistic Analysis</div>
            <p className="text-slate-400">Evaluates clickbait indicators, emotional fear/urgency density, subjectivity, and Flesch readability scores.</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-cyan-400 font-bold font-mono">Stage 4: Domain & Source Index</div>
            <p className="text-slate-400">Corroborates publisher against authoritative registries (NASA, Nature, Reuters, WHO) and checks bylines.</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-cyan-400 font-bold font-mono">Stage 5: Evidence Matching</div>
            <p className="text-slate-400">Cross-checks claims with verified scientific and news fact triples, determining individual claim veracity.</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-cyan-400 font-bold font-mono">Stage 6: Score Synthesis</div>
            <p className="text-slate-400">Calculates composite weighted 0–100 score and formats explainable natural language rationale.</p>
          </div>
        </div>
      </section>

      {/* 4. MATHEMATICAL FORMULATION */}
      <section className="p-6 sm:p-8 rounded-3xl glass-panel border border-slate-800 space-y-6">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Code2 className="w-5 h-5 text-cyan-400" />
          Mathematical Scoring Formulation
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          The aggregate Trust Score T (between 0 and 100) is formalized as a normalized convex linear combination of 6 modular feature sub-scores:
        </p>

        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-cyan-300 text-xs sm:text-sm text-center leading-relaxed">
          {"Trust Score = (w₁ · SourceCredibility) + (w₂ · EvidenceStrength) + (w₃ · ClaimConsistency) + (w₄ · CrossAgreement) + (w₅ · Cleanliness) + (w₆ · Context)"}
          <div className="text-slate-500 text-xs mt-2 font-sans">
            where ∑ wᵢ = 1.0 (Default: w₁=0.25, w₂=0.25, w₃=0.20, w₄=0.15, w₅=0.10, w₆=0.05)
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
            <span className="font-bold text-white">Source Credibility (25%):</span> Domain authority index, academic TLDs & DOI citation factors.
          </div>
          <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
            <span className="font-bold text-white">Evidence Strength (25%):</span> Peer-reviewed corroboration and primary citation density.
          </div>
          <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
            <span className="font-bold text-white">Claim Consistency (20%):</span> Ratio of supported vs contradicted propositions.
          </div>
          <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
            <span className="font-bold text-white">Cross-Source Agreement (15%):</span> Independent registry consensus index.
          </div>
          <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
            <span className="font-bold text-white">Language Cleanliness (10%):</span> Penalty-subtracted metric for sensationalism, fear rhetoric & clickbait.
          </div>
          <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
            <span className="font-bold text-white">Context Completeness (5%):</span> Propositional depth, metadata and word count sufficiency.
          </div>
        </div>
      </section>

      {/* 5. ADVANTAGES, LIMITATIONS & FUTURE SCOPE */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 sm:p-8 rounded-3xl glass-panel border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            Key System Advantages
          </h3>
          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span><strong>Zero-latency local fallback:</strong> Works deterministically even during network or external API downtime.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span><strong>Fine-Grained Claim Verification:</strong> Pinpoints specific deceptive clauses rather than applying vague blanket labels.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span><strong>Tunable Academic Weights:</strong> Enables domain researchers to adapt weightings for medical, political, or scientific datasets.</span>
            </li>
          </ul>
        </div>

        <div className="p-6 sm:p-8 rounded-3xl glass-panel border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Compass className="w-4 h-4 text-cyan-400" />
            Future Research Scope
          </h3>
          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-start gap-2">
              <ArrowRight className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
              <span><strong>Multilingual Misinformation:</strong> Cross-lingual transformer embedding for regional language fact checking.</span>
            </li>
            <li className="flex items-start gap-2">
              <ArrowRight className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
              <span><strong>Multimodal Deepfake Fusion:</strong> Video frame and voice-clone synthesis forensics integrated with text claims.</span>
            </li>
            <li className="flex items-start gap-2">
              <ArrowRight className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
              <span><strong>Browser Extension & Mobile App:</strong> Real-time in-situ social feed highlighting on X, Reddit, and news feeds.</span>
            </li>
          </ul>
        </div>
      </section>

      {/* 6. ACADEMIC BIBTEX CITATION */}
      <section className="p-6 sm:p-8 rounded-3xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            Academic Citation (BibTeX)
          </h3>
          <button
            onClick={copyBibtex}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            {copiedBibtex ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedBibtex ? 'Copied to Clipboard!' : 'Copy BibTeX'}</span>
          </button>
        </div>

        <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-cyan-300 font-mono overflow-x-auto leading-relaxed">
          {bibtexCitation}
        </pre>
      </section>
    </div>
  );
};
