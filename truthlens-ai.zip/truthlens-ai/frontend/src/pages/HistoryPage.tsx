import React, { useEffect, useState } from 'react';
import { 
  History as HistoryIcon, 
  Search, 
  Trash2, 
  ExternalLink, 
  Filter, 
  Loader2, 
  AlertCircle, 
  CheckCircle2, 
  XCircle, 
  HelpCircle,
  FileText,
  Globe,
  Image as ImageIcon,
  Type,
  Sparkles
} from 'lucide-react';
import { AnalysisSummary, ContentType } from '../types';
import { api } from '../services/api';

interface HistoryPageProps {
  onViewAnalysis: (id: string) => void;
  onNavigate: (page: string) => void;
}

export const HistoryPage: React.FC<HistoryPageProps> = ({ onViewAnalysis, onNavigate }) => {
  const [history, setHistory] = useState<AnalysisSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedClassification, setSelectedClassification] = useState('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const data = await api.history.getAll({
        query: searchQuery || undefined,
        content_type: selectedType !== 'all' ? selectedType : undefined,
        classification: selectedClassification !== 'all' ? selectedClassification : undefined,
      });
      setHistory(data);
    } catch (e) {
      console.error('Failed to load history:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [selectedType, selectedClassification]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchHistory();
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this analysis record?')) return;
    setDeletingId(id);
    try {
      await api.history.delete(id);
      setHistory((prev) => prev.filter((item) => item.id !== id));
    } catch (err) {
      console.error('Delete error:', err);
    } finally {
      setDeletingId(null);
    }
  };

  const handleClearAll = async () => {
    if (!confirm('Clear all analysis history?')) return;
    try {
      await api.history.clearAll();
      setHistory([]);
    } catch (err) {
      console.error('Clear all error:', err);
    }
  };

  const getTypeIcon = (type: ContentType) => {
    switch (type) {
      case 'url': return Globe;
      case 'document': return FileText;
      case 'image': return ImageIcon;
      default: return Type;
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-xs font-semibold text-cyan-300">
            <HistoryIcon className="w-3.5 h-3.5 text-cyan-400" />
            Audit Log & History
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Inspection History</h1>
          <p className="text-xs text-slate-400">Search and review past content fact-checking assessments.</p>
        </div>

        {history.length > 0 && (
          <button
            onClick={handleClearAll}
            className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-semibold border border-rose-500/30 transition flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl glass-panel border border-slate-800 space-y-4">
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
            <input
              type="text"
              placeholder="Search by keywords, title, or claims..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition"
            />
          </div>

          {/* Type Filter */}
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="all">All Content Types</option>
            <option value="text">Text Snippets</option>
            <option value="url">Website URLs</option>
            <option value="document">Documents (PDF/DOCX)</option>
            <option value="image">Images / OCR</option>
            <option value="demo">Demo Benchmarks</option>
          </select>

          {/* Classification Filter */}
          <select
            value={selectedClassification}
            onChange={(e) => setSelectedClassification(e.target.value)}
            className="px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="all">All Classifications</option>
            <option value="Highly Trustworthy">Highly Trustworthy</option>
            <option value="Mostly Trustworthy">Mostly Trustworthy</option>
            <option value="Needs Verification">Needs Verification</option>
            <option value="Likely Misleading">Likely Misleading</option>
            <option value="Likely False">Likely False</option>
          </select>

          <button
            type="submit"
            className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition"
          >
            Search
          </button>
        </form>
      </div>

      {/* History List */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center space-y-3">
          <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          <p className="text-xs text-slate-400">Loading historical inspection records...</p>
        </div>
      ) : history.length === 0 ? (
        <div className="p-12 rounded-3xl glass-panel border border-slate-800 text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-500 mx-auto">
            <HistoryIcon className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">No Analysis Records Found</h3>
            <p className="text-xs text-slate-400 mt-1">Start by analyzing an article, URL, or document.</p>
          </div>
          <button
            onClick={() => onNavigate('analyze')}
            className="px-6 py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs inline-flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Launch Analyzer</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {history.map((record) => {
            const Icon = getTypeIcon(record.content_type);
            const score = record.trust_score;
            return (
              <div
                key={record.id}
                onClick={() => onViewAnalysis(record.id)}
                className="p-5 rounded-2xl glass-panel border border-slate-800 hover:border-slate-700 hover:bg-slate-900/90 transition cursor-pointer flex flex-col md:flex-row items-start md:items-center justify-between gap-4 group"
              >
                <div className="flex items-start gap-4 truncate">
                  <div className="p-3 rounded-xl bg-slate-800 flex-shrink-0 text-cyan-400">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="space-y-1 truncate">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                        {record.content_type}
                      </span>
                      {record.is_demo && (
                        <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
                          Demo
                        </span>
                      )}
                      <span className="text-xs text-slate-500 font-mono">
                        {new Date(record.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition truncate max-w-xl">
                      {record.content_title || 'Content Inspection Record'}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-6 self-end md:self-center flex-shrink-0">
                  <div className="text-right">
                    <div className={`text-base font-extrabold font-mono ${
                      score >= 80 ? 'text-emerald-400' :
                      score >= 60 ? 'text-cyan-400' :
                      score >= 40 ? 'text-amber-400' :
                      score >= 20 ? 'text-orange-400' : 'text-rose-500'
                    }`}>
                      {Math.round(score)}/100
                    </div>
                    <div className="text-[11px] font-semibold text-slate-300">
                      {record.classification}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => { e.stopPropagation(); onViewAnalysis(record.id); }}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500/20 text-slate-200 hover:text-cyan-300 text-xs font-semibold transition"
                    >
                      View Report
                    </button>
                    <button
                      onClick={(e) => handleDelete(record.id, e)}
                      disabled={deletingId === record.id}
                      className="p-2 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition"
                      title="Delete Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
