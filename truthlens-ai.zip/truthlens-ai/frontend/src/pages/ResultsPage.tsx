import React, { useState } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  ExternalLink, 
  Share2, 
  Download, 
  ArrowLeft, 
  ThumbsUp, 
  ThumbsDown, 
  Sparkles, 
  Layers, 
  BarChart2, 
  MessageSquare,
  FileCheck,
  AlertOctagon,
  Copy,
  Check
} from 'lucide-react';
import { AnalysisResult, ClaimVerdict } from '../types';
import { ScoreGauge } from '../components/ui/ScoreGauge';
import { api } from '../services/api';

interface ResultsPageProps {
  result: AnalysisResult;
  onBack: () => void;
}

export const ResultsPage: React.FC<ResultsPageProps> = ({ result, onBack }) => {
  const [feedbackRating, setFeedbackRating] = useState<number | null>(null);
  const [feedbackComment, setFeedbackComment] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);

  const getVerdictBadge = (verdict: ClaimVerdict) => {
    switch (verdict) {
      case 'Supported':
        return {
          icon: CheckCircle2,
          bg: 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400',
          label: 'Supported'
        };
      case 'Contradicted':
        return {
          icon: XCircle,
          bg: 'bg-rose-500/15 border-rose-500/30 text-rose-400',
          label: 'Contradicted'
        };
      case 'Partially Supported':
        return {
          icon: AlertTriangle,
          bg: 'bg-cyan-500/15 border-cyan-500/30 text-cyan-300',
          label: 'Partially Supported'
        };
      default:
        return {
          icon: HelpCircle,
          bg: 'bg-amber-500/15 border-amber-500/30 text-amber-400',
          label: 'Needs Verification'
        };
    }
  };

  const handleFeedbackSubmit = async (rating: number) => {
    try {
      setFeedbackRating(rating);
      await api.feedback.submit({
        analysis_id: result.id,
        rating,
        comment: feedbackComment || undefined
      });
      setFeedbackSubmitted(true);
    } catch (e) {
      console.error('Feedback error:', e);
    }
  };

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(result, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `truthlens_report_${result.id.slice(0, 8)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleCopySummary = () => {
    const summary = `TruthLens AI Verification Report:
Verdict: ${result.classification} (Score: ${result.trust_score}/100)
Confidence: ${result.confidence}% | Risk Level: ${result.risk_level}
Summary: ${result.explanation}`;
    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const supportingSources = result.sources.filter(s => s.source_type === 'supporting');
  const contradictingSources = result.sources.filter(s => s.source_type === 'contradicting');
  const referenceSources = result.sources.filter(s => s.source_type === 'reference');

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8 animate-fade-in">
      {/* Top action toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-700 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Analysis Studio</span>
        </button>

        <div className="flex items-center gap-2">
          {result.is_demo && (
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-500/15 border border-purple-500/30 text-purple-300">
              Demo / Simulated Benchmark
            </span>
          )}
          <button
            onClick={handleCopySummary}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-700 transition flex items-center gap-1.5"
            title="Copy Report Summary"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span className="hidden sm:inline">{copied ? 'Copied!' : 'Copy Summary'}</span>
          </button>
          <button
            onClick={handleExportJSON}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-700 transition flex items-center gap-1.5"
            title="Export JSON Report"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export JSON</span>
          </button>
        </div>
      </div>

      {/* AI SAFETY NOTICE */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="text-xs text-amber-200/90 leading-relaxed">
          <strong>TruthLens AI Automated Safety Disclaimer:</strong> This report represents an algorithmic assessment based on semantic claim extraction, domain reputation, and peer-reviewed corpus alignment. It should not be considered an absolute fact-checking authority. Always verify critical decisions using verified primary sources.
        </div>
      </div>

      {/* PRIMARY SUMMARY HERO CARD */}
      <div className="rounded-3xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl p-6 sm:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Col: Gauge & Badges */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center border-b lg:border-b-0 lg:border-r border-slate-800 pb-6 lg:pb-0 lg:pr-6">
            <ScoreGauge
              score={result.trust_score}
              classification={result.classification}
              confidence={result.confidence}
              riskLevel={result.risk_level}
              size={210}
            />
          </div>

          {/* Right Col: Title & AI Explanation */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-500/10 px-2.5 py-0.5 rounded-full border border-cyan-500/20">
                {result.content_type.toUpperCase()} INGESTION
              </span>
              <span className="text-xs text-slate-500">
                Analyzed on {new Date(result.created_at || Date.now()).toLocaleDateString()}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-white leading-snug">
              {result.content_title || 'Submitted Content Verification'}
            </h2>

            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Explainable AI (XAI) Synthesis:</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {result.explanation}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* WEIGHTED SCORE BREAKDOWN & LINGUISTIC METRICS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Score Breakdown */}
        {result.score_breakdown && (
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-cyan-400" />
                Weighted Component Breakdown
              </h3>
              <span className="text-[10px] uppercase font-bold text-slate-400">Formula Weights</span>
            </div>

            <div className="space-y-3 text-xs">
              {[
                { label: 'Source Credibility (25%)', val: result.score_breakdown.source_credibility },
                { label: 'Evidence Strength (25%)', val: result.score_breakdown.evidence_strength },
                { label: 'Claim Consistency (20%)', val: result.score_breakdown.claim_consistency },
                { label: 'Cross-Source Agreement (15%)', val: result.score_breakdown.cross_source_agreement },
                { label: 'Language Cleanliness (10%)', val: result.score_breakdown.language_manipulation_cleanliness },
                { label: 'Context Completeness (5%)', val: result.score_breakdown.context_completeness },
              ].map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-slate-300">
                    <span>{item.label}</span>
                    <span className="font-mono font-bold text-cyan-400">{Math.round(item.val)}/100</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        item.val >= 75 ? 'bg-emerald-400' : item.val >= 50 ? 'bg-cyan-400' : item.val >= 30 ? 'bg-amber-400' : 'bg-rose-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(0, item.val))}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Linguistic & Emotional Analysis */}
        {result.linguistic_metrics && (
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                Linguistic & Emotional Metrics
              </h3>
              <span className="text-[10px] uppercase font-bold text-slate-400">
                {result.linguistic_metrics.word_count} Words
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-slate-400 mb-1">Clickbait Index</div>
                <div className={`text-base font-bold font-mono ${result.linguistic_metrics.clickbait_score > 35 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {result.linguistic_metrics.clickbait_score}/100
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  {result.linguistic_metrics.clickbait_score > 35 ? 'Sensational Headline' : 'Objective Phrasing'}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-slate-400 mb-1">Sentiment Polarity</div>
                <div className="text-base font-bold font-mono text-cyan-300">
                  {result.linguistic_metrics.sentiment.label}
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  Compound: {result.linguistic_metrics.sentiment.compound}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-slate-400 mb-1">Readability Level</div>
                <div className="text-sm font-bold text-slate-200 truncate">
                  {result.linguistic_metrics.readability_level}
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  Flesch: {result.linguistic_metrics.flesch_score || 65}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-slate-400 mb-1">Emotional Intensity</div>
                <div className="text-sm font-bold text-slate-200">
                  Sensationalism: {Math.round(result.linguistic_metrics.emotional_intensity.sensationalism)}%
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  Fear: {Math.round(result.linguistic_metrics.emotional_intensity.fear)}% • Urgency: {Math.round(result.linguistic_metrics.emotional_intensity.urgency)}%
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* CLAIM-BY-CLAIM ANALYSIS SECTION */}
      <div className="p-6 sm:p-8 rounded-3xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-cyan-400" />
              Claim-by-Claim Verification
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Individual propositional decomposition and factual corroboration against evidence archives.
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-slate-400">
            {result.claims.length} Claims Identified
          </span>
        </div>

        <div className="space-y-4">
          {result.claims.length === 0 ? (
            <div className="text-center py-6 text-slate-500 text-xs">
              No distinct factual assertions detected in this sample.
            </div>
          ) : (
            result.claims.map((claim, idx) => {
              const badge = getVerdictBadge(claim.verdict);
              const Icon = badge.icon;
              return (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800/90 space-y-3 hover:border-slate-700 transition"
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <span className="text-xs font-bold text-slate-400 font-mono">
                      Claim #{idx + 1} {claim.category && `• ${claim.category}`}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${badge.bg}`}>
                        <Icon className="w-3.5 h-3.5" />
                        {badge.label}
                      </span>
                      <span className="text-[11px] font-mono text-slate-400">
                        {Math.round(claim.confidence)}% Conf.
                      </span>
                    </div>
                  </div>

                  <p className="text-sm font-semibold text-slate-100 leading-relaxed">
                    “{claim.claim_text}”
                  </p>

                  <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-300 space-y-1">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      Corroborating / Contradicting Evidence:
                    </div>
                    <p className="leading-relaxed">{claim.evidence}</p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* SUPPORTING & CONTRADICTING SOURCES */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Supporting Sources */}
        <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Supporting & Reference Sources ({supportingSources.length + referenceSources.length})
          </h3>
          <div className="space-y-2.5 text-xs">
            {supportingSources.length === 0 && referenceSources.length === 0 ? (
              <p className="text-slate-500 text-xs">No direct supporting sources corroborated this content.</p>
            ) : (
              [...supportingSources, ...referenceSources].map((src, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
                  <div className="space-y-0.5 truncate">
                    <div className="font-semibold text-slate-200 truncate">{src.title}</div>
                    <div className="text-[11px] text-slate-500 truncate">{src.domain || 'Verified Knowledge Base'}</div>
                  </div>
                  {src.url ? (
                    <a
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  ) : null}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Contradicting Sources */}
        <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <XCircle className="w-4 h-4 text-rose-400" />
            Contradicting & Refuting Sources ({contradictingSources.length})
          </h3>
          <div className="space-y-2.5 text-xs">
            {contradictingSources.length === 0 ? (
              <p className="text-slate-500 text-xs">No formal scientific or journalistic contradictions identified.</p>
            ) : (
              contradictingSources.map((src, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
                  <div className="space-y-0.5 truncate">
                    <div className="font-semibold text-slate-200 truncate">{src.title}</div>
                    <div className="text-[11px] text-rose-400/80 truncate">Refutation • {src.domain}</div>
                  </div>
                  {src.url ? (
                    <a
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  ) : null}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* USER FEEDBACK WIDGET */}
      <div className="p-6 rounded-2xl glass-panel border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center sm:text-left">
          <h4 className="text-sm font-bold text-white flex items-center gap-2 justify-center sm:justify-start">
            <MessageSquare className="w-4 h-4 text-cyan-400" />
            Was this automated AI assessment accurate & helpful?
          </h4>
          <p className="text-xs text-slate-400">
            Your feedback actively calibrates our academic credibility models and claim verification weights.
          </p>
        </div>

        {feedbackSubmitted ? (
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-4 py-2 rounded-xl border border-emerald-500/30">
            <CheckCircle2 className="w-4 h-4" />
            <span>Thank you for your feedback!</span>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleFeedbackSubmit(5)}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-emerald-500/20 hover:text-emerald-300 text-slate-300 text-xs font-semibold border border-slate-700 transition flex items-center gap-1.5"
            >
              <ThumbsUp className="w-3.5 h-3.5" />
              <span>Accurate</span>
            </button>
            <button
              onClick={() => handleFeedbackSubmit(1)}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-rose-500/20 hover:text-rose-300 text-slate-300 text-xs font-semibold border border-slate-700 transition flex items-center gap-1.5"
            >
              <ThumbsDown className="w-3.5 h-3.5" />
              <span>Inaccurate</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
