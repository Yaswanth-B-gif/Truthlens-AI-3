import React, { useState, useEffect } from 'react';
import { 
  Type, 
  Globe, 
  FileText, 
  Image as ImageIcon, 
  Sparkles, 
  RotateCcw, 
  UploadCloud, 
  AlertCircle, 
  Sliders, 
  CheckCircle2, 
  Loader2,
  ChevronDown,
  ChevronUp,
  FileCode2,
  X
} from 'lucide-react';
import { api } from '../services/api';
import { AnalysisResult, ContentType } from '../types';

interface AnalyzePageProps {
  onAnalysisComplete: (result: AnalysisResult) => void;
  presetScenario?: string | null;
}

export const AnalyzePage: React.FC<AnalyzePageProps> = ({ onAnalysisComplete, presetScenario }) => {
  const [activeTab, setActiveTab] = useState<ContentType>('text');
  
  // Inputs
  const [textInput, setTextInput] = useState('');
  const [titleInput, setTitleInput] = useState('');
  const [urlInput, setUrlInput] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);

  // Advanced weight configuration
  const [showWeightConfig, setShowWeightConfig] = useState(false);
  const [weights, setWeights] = useState({
    source_credibility: 0.25,
    evidence_strength: 0.25,
    claim_consistency: 0.20,
    cross_source_agreement: 0.15,
    language_manipulation_cleanliness: 0.10,
    context_completeness: 0.05,
  });

  // State
  const [loading, setLoading] = useState(false);
  const [progressStep, setProgressStep] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const processingSteps = [
    'Ingesting and extracting raw content...',
    'Performing text cleaning & tokenization...',
    'Extracting verifiable factual claims & entities...',
    'Conducting linguistic & clickbait sentiment analysis...',
    'Querying peer-reviewed and authoritative evidence registries...',
    'Assessing domain and author credibility signals...',
    'Synthesizing final weighted Trust Score and XAI explanation...'
  ];

  // Auto trigger if presetScenario is passed
  useEffect(() => {
    if (presetScenario) {
      handleDemoRun(presetScenario);
    }
  }, [presetScenario]);

  const handleDemoRun = async (scenarioKey: string) => {
    setError(null);
    setLoading(true);
    setProgressStep(0);

    // Animate through steps
    const interval = setInterval(() => {
      setProgressStep((prev) => (prev < processingSteps.length - 1 ? prev + 1 : prev));
    }, 320);

    try {
      const result = await api.analyze.demo(scenarioKey);
      clearInterval(interval);
      setProgressStep(processingSteps.length - 1);
      setTimeout(() => {
        setLoading(false);
        onAnalysisComplete(result);
      }, 400);
    } catch (err: any) {
      clearInterval(interval);
      setLoading(false);
      setError(err.response?.data?.detail || err.message || 'Analysis failed. Please try again.');
    }
  };

  const handleAnalyze = async () => {
    setError(null);
    setLoading(true);
    setProgressStep(0);

    const interval = setInterval(() => {
      setProgressStep((prev) => (prev < processingSteps.length - 1 ? prev + 1 : prev));
    }, 450);

    try {
      let result: AnalysisResult;
      const customWeights = showWeightConfig ? weights : undefined;

      if (activeTab === 'text') {
        if (!textInput.trim() || textInput.trim().length < 15) {
          throw new Error('Please enter at least 15 characters of text to analyze.');
        }
        result = await api.analyze.text(textInput, titleInput || undefined, customWeights);
      } else if (activeTab === 'url') {
        if (!urlInput.trim() || !urlInput.includes('.')) {
          throw new Error('Please enter a valid website URL (e.g. https://reuters.com/article).');
        }
        result = await api.analyze.url(urlInput, customWeights);
      } else if (activeTab === 'document') {
        if (!selectedFile) {
          throw new Error('Please select or drop a document file (PDF, DOCX, or TXT).');
        }
        result = await api.analyze.file(selectedFile);
      } else if (activeTab === 'image') {
        if (!selectedFile) {
          throw new Error('Please select or drop an image file (PNG, JPG, or WEBP).');
        }
        result = await api.analyze.image(selectedFile);
      } else {
        throw new Error('Invalid analysis type selected.');
      }

      clearInterval(interval);
      setProgressStep(processingSteps.length - 1);
      setTimeout(() => {
        setLoading(false);
        onAnalysisComplete(result);
      }, 500);
    } catch (err: any) {
      clearInterval(interval);
      setLoading(false);
      setError(err.response?.data?.detail || err.message || 'Failed to complete analysis.');
    }
  };

  const handleClear = () => {
    setTextInput('');
    setTitleInput('');
    setUrlInput('');
    setSelectedFile(null);
    setError(null);
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const sampleTexts = {
    science: "Astronomers using the James Webb Space Telescope (JWST) have discovered high-redshift galaxies formed within 350 million years of the Big Bang, confirming rapid primordial stellar synthesis models.",
    health_rumor: "Drinking boiled garlic with fresh lemon water every morning completely eliminates all respiratory viruses and is 100% guaranteed to prevent infection according to holistic healers.",
    tech_quantum: "IBM Quantum researchers have successfully demonstrated fault-tolerant logical quantum circuits with dynamic error mitigation, achieving 1,000+ entangled physical qubits."
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-xs font-semibold text-cyan-300">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          Multi-Format Ingestion Studio
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">Content Fact & Credibility Analyzer</h1>
        <p className="text-slate-400 text-sm max-w-xl mx-auto">
          Submit articles, URLs, documents, or screenshots to extract claims, detect clickbait bias, and generate a verified Trust Score.
        </p>
      </div>

      {/* Preset Demo Quick Buttons */}
      <div className="p-4 rounded-xl glass-panel border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
        <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          Benchmark Demos:
        </span>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => handleDemoRun('trustworthy')}
            disabled={loading}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 transition disabled:opacity-50"
          >
            Trustworthy Science
          </button>
          <button
            onClick={() => handleDemoRun('misleading')}
            disabled={loading}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 transition disabled:opacity-50"
          >
            Misleading Health
          </button>
          <button
            onClick={() => handleDemoRun('false')}
            disabled={loading}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 transition disabled:opacity-50"
          >
            False Conspiracy
          </button>
          <button
            onClick={() => handleDemoRun('clickbait')}
            disabled={loading}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-orange-500/15 hover:bg-orange-500/25 text-orange-300 border border-orange-500/30 transition disabled:opacity-50"
          >
            Clickbait Post
          </button>
        </div>
      </div>

      {/* Main Analysis Card */}
      <div className="rounded-2xl glass-panel-glow bg-slate-900 border border-slate-700/80 shadow-2xl overflow-hidden">
        {/* Ingestion Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 overflow-x-auto">
          {[
            { id: 'text', label: 'Text Snippet', icon: Type },
            { id: 'url', label: 'Website URL', icon: Globe },
            { id: 'document', label: 'Document (PDF/DOCX)', icon: FileText },
            { id: 'image', label: 'Image / Screenshot', icon: ImageIcon },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id as ContentType); setError(null); }}
                disabled={loading}
                className={`flex items-center gap-2 px-6 py-4 text-xs sm:text-sm font-semibold border-b-2 transition whitespace-nowrap ${
                  isActive
                    ? 'border-cyan-400 text-cyan-400 bg-slate-900/80'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Error Message */}
          {error && (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* TAB 1: TEXT */}
          {activeTab === 'text' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Optional Article Title or Headline
                </label>
                <input
                  type="text"
                  placeholder="e.g. Breakthrough in nuclear fusion energy reported by research team"
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  disabled={loading}
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Content Text to Analyze <span className="text-rose-400">*</span>
                  </label>
                  <span className="text-[11px] text-slate-500 font-mono">
                    {textInput.split(/\s+/).filter(Boolean).length} words • {textInput.length} chars
                  </span>
                </div>
                <textarea
                  rows={8}
                  placeholder="Paste digital text, news article, viral claim, social media post, or transcript here..."
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  disabled={loading}
                  className="w-full p-4 bg-slate-950 border border-slate-800 rounded-xl text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition leading-relaxed resize-y"
                ></textarea>
              </div>

              {/* Sample loader chips */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-[11px] font-semibold text-slate-400">Quick Insert Sample:</span>
                <button
                  type="button"
                  onClick={() => setTextInput(sampleTexts.science)}
                  className="text-[11px] px-2.5 py-1 rounded bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700 transition"
                >
                  JWST Space Observation
                </button>
                <button
                  type="button"
                  onClick={() => setTextInput(sampleTexts.health_rumor)}
                  className="text-[11px] px-2.5 py-1 rounded bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700 transition"
                >
                  Boiled Lemon Rumor
                </button>
                <button
                  type="button"
                  onClick={() => setTextInput(sampleTexts.tech_quantum)}
                  className="text-[11px] px-2.5 py-1 rounded bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700 transition"
                >
                  Quantum Computing News
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: URL */}
          {activeTab === 'url' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Article or Webpage URL <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <Globe className="w-5 h-5 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="url"
                    placeholder="https://www.reuters.com/world/science/article-headline"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    disabled={loading}
                    className="w-full pl-11 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition"
                  />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-400 space-y-1">
                <div className="font-semibold text-slate-300">How URL Ingestion Works:</div>
                <p>TruthLens AI will automatically scrape the publication body, parse metadata, evaluate domain credibility against registry indexes, and decompose claims.</p>
              </div>
            </div>
          )}

          {/* TAB 3: DOCUMENT */}
          {activeTab === 'document' && (
            <div className="space-y-4">
              <div
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleFileDrop}
                className={`p-8 rounded-2xl border-2 border-dashed transition text-center cursor-pointer ${
                  dragOver ? 'border-cyan-400 bg-cyan-500/10' : 'border-slate-800 hover:border-slate-700 bg-slate-950/40'
                }`}
                onClick={() => document.getElementById('file-upload-doc')?.click()}
              >
                <input
                  id="file-upload-doc"
                  type="file"
                  accept=".pdf,.docx,.txt,.md"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && setSelectedFile(e.target.files[0])}
                />
                <div className="flex flex-col items-center justify-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 flex items-center justify-center text-cyan-400">
                    <UploadCloud className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-slate-200">
                      {selectedFile ? selectedFile.name : 'Click to select or drag and drop document'}
                    </span>
                    <p className="text-xs text-slate-500 mt-1">Supports PDF, DOCX, TXT (Max 10MB)</p>
                  </div>
                </div>
              </div>

              {selectedFile && (
                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2 text-slate-300">
                    <FileText className="w-4 h-4 text-cyan-400" />
                    <span>{selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)</span>
                  </div>
                  <button onClick={() => setSelectedFile(null)} className="text-slate-400 hover:text-rose-400">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: IMAGE */}
          {activeTab === 'image' && (
            <div className="space-y-4">
              <div
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleFileDrop}
                className={`p-8 rounded-2xl border-2 border-dashed transition text-center cursor-pointer ${
                  dragOver ? 'border-cyan-400 bg-cyan-500/10' : 'border-slate-800 hover:border-slate-700 bg-slate-950/40'
                }`}
                onClick={() => document.getElementById('file-upload-img')?.click()}
              >
                <input
                  id="file-upload-img"
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && setSelectedFile(e.target.files[0])}
                />
                <div className="flex flex-col items-center justify-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 flex items-center justify-center text-cyan-400">
                    <ImageIcon className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-slate-200">
                      {selectedFile ? selectedFile.name : 'Click to select or drag and drop image screenshot'}
                    </span>
                    <p className="text-xs text-slate-500 mt-1">Supports PNG, JPG, WEBP with OCR parsing</p>
                  </div>
                </div>
              </div>

              {selectedFile && (
                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2 text-slate-300">
                    <ImageIcon className="w-4 h-4 text-cyan-400" />
                    <span>{selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)</span>
                  </div>
                  <button onClick={() => setSelectedFile(null)} className="text-slate-400 hover:text-rose-400">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Collapsible Advanced Scoring Weights Configuration */}
          <div className="pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setShowWeightConfig(!showWeightConfig)}
              className="flex items-center justify-between w-full text-xs font-semibold text-slate-400 hover:text-cyan-400 transition py-1"
            >
              <span className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5" />
                Advanced: Configurable Scoring Weights Formula (Research Mode)
              </span>
              {showWeightConfig ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showWeightConfig && (
              <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-4 text-xs animate-fade-in">
                <p className="text-slate-400">
                  Adjust parameter weights for the transparent scoring equation: 
                  <code className="text-cyan-300 ml-1 font-mono">Score = ∑ (Weight_i × Metric_i)</code>
                </p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="flex justify-between text-slate-300 mb-1">
                      <span>Source Credibility</span>
                      <span className="font-mono text-cyan-400">{(weights.source_credibility * 100).toFixed(0)}%</span>
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="0.5"
                      step="0.05"
                      value={weights.source_credibility}
                      onChange={(e) => setWeights({ ...weights, source_credibility: parseFloat(e.target.value) })}
                      className="w-full accent-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="flex justify-between text-slate-300 mb-1">
                      <span>Evidence Strength</span>
                      <span className="font-mono text-cyan-400">{(weights.evidence_strength * 100).toFixed(0)}%</span>
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="0.5"
                      step="0.05"
                      value={weights.evidence_strength}
                      onChange={(e) => setWeights({ ...weights, evidence_strength: parseFloat(e.target.value) })}
                      className="w-full accent-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="flex justify-between text-slate-300 mb-1">
                      <span>Claim Consistency</span>
                      <span className="font-mono text-cyan-400">{(weights.claim_consistency * 100).toFixed(0)}%</span>
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="0.5"
                      step="0.05"
                      value={weights.claim_consistency}
                      onChange={(e) => setWeights({ ...weights, claim_consistency: parseFloat(e.target.value) })}
                      className="w-full accent-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="flex justify-between text-slate-300 mb-1">
                      <span>Cross-Source Agreement</span>
                      <span className="font-mono text-cyan-400">{(weights.cross_source_agreement * 100).toFixed(0)}%</span>
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="0.5"
                      step="0.05"
                      value={weights.cross_source_agreement}
                      onChange={(e) => setWeights({ ...weights, cross_source_agreement: parseFloat(e.target.value) })}
                      className="w-full accent-cyan-400"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
            <button
              type="button"
              onClick={handleClear}
              disabled={loading}
              className="px-4 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Clear Input
            </button>

            <button
              type="button"
              onClick={handleAnalyze}
              disabled={loading}
              className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-teal-400 hover:opacity-95 text-slate-950 font-bold text-sm shadow-xl shadow-cyan-500/25 flex items-center gap-2 transition disabled:opacity-50 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>{loading ? 'Analyzing Content...' : 'Run TruthLens AI Analysis'}</span>
            </button>
          </div>
        </div>

        {/* Dynamic Multi-Stage Processing Indicator Modal / Overlay */}
        {loading && (
          <div className="p-8 border-t border-slate-800 bg-slate-950/90 backdrop-blur-sm space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Loader2 className="w-6 h-6 text-cyan-400 animate-spin" />
                <div>
                  <h4 className="text-sm font-bold text-white">AI Fact-Checking Pipeline In Progress</h4>
                  <p className="text-xs text-cyan-300 font-mono mt-0.5">
                    Step {progressStep + 1} of {processingSteps.length}: {processingSteps[progressStep]}
                  </p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-slate-400">
                {Math.round(((progressStep + 1) / processingSteps.length) * 100)}%
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 via-cyan-400 to-teal-300 transition-all duration-300 ease-out"
                style={{ width: `${((progressStep + 1) / processingSteps.length) * 100}%` }}
              ></div>
            </div>

            {/* Step Checkpoints */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-[11px]">
              {processingSteps.slice(0, 4).map((step, idx) => (
                <div key={idx} className="flex items-center gap-1.5 text-slate-400">
                  {progressStep >= idx ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                  ) : (
                    <span className="w-3.5 h-3.5 rounded-full border border-slate-700 flex-shrink-0"></span>
                  )}
                  <span className={`truncate ${progressStep >= idx ? 'text-slate-200 font-medium' : ''}`}>
                    {step.replace('Conducting ', '').replace('Assessing ', '')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
