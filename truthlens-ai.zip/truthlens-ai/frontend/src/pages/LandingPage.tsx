import React from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Search, 
  Cpu, 
  Layers, 
  BarChart3, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  Globe, 
  Image as ImageIcon, 
  ArrowRight,
  Zap,
  Lock,
  BookOpen
} from 'lucide-react';
import { ScoreGauge } from '../components/ui/ScoreGauge';

interface LandingPageProps {
  onNavigate: (page: string) => void;
  onSelectDemo: (scenario: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, onSelectDemo }) => {
  return (
    <div className="space-y-24 py-6">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-8 pb-12">
        {/* Glow ambient background elements */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-gradient-to-tr from-cyan-600/20 via-blue-600/20 to-indigo-600/10 rounded-full blur-3xl pointer-events-none -z-10"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-panel border border-cyan-500/30 text-xs font-semibold text-cyan-300">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Next-Gen NLP & Automated Claim Verification Engine</span>
          </div>

          {/* Headline & Subhead */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-5xl mx-auto leading-[1.1]">
            Detect False Information.{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500 bg-clip-text text-transparent">
              Discover What You Can Trust.
            </span>
          </h1>

          <p className="text-base sm:text-xl text-slate-300 max-w-3xl mx-auto font-normal leading-relaxed">
            AI-powered data-driven analysis for identifying misleading, false, and trustworthy digital content. Ingest articles, URLs, documents, and images with transparent score explanations.
          </p>

          {/* Call to Actions */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              onClick={() => onNavigate('analyze')}
              className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-teal-400 hover:opacity-95 text-slate-950 font-bold text-base shadow-xl shadow-cyan-500/25 flex items-center gap-2.5 transition transform hover:-translate-y-0.5"
            >
              <Sparkles className="w-5 h-5" />
              <span>Analyze Content Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onSelectDemo('trustworthy')}
              className="px-6 py-3.5 rounded-xl glass-panel hover:bg-slate-800/80 border border-slate-700 text-slate-200 font-semibold text-base flex items-center gap-2 transition"
            >
              <span>Try Demo Scenarios</span>
            </button>
          </div>

          {/* Live Hero Mockup / Interactive Score Preview Card */}
          <div className="pt-10 max-w-4xl mx-auto">
            <div className="glass-panel-glow rounded-2xl p-6 sm:p-8 bg-slate-900/90 border border-slate-700/80 shadow-2xl text-left">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-b border-slate-800 pb-6">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                    Live AI Verification Preview
                  </div>
                  <h3 className="text-lg font-bold text-white mt-1">
                    NASA James Webb Space Telescope Confirms Ancient Primordial Galaxies
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Nature Astronomy • DOI: 10.1038/s41586 • Peer-reviewed Spectroscopic Observation
                  </p>
                </div>
                <div className="flex-shrink-0">
                  <div className="px-4 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-[10px] uppercase font-bold text-slate-400">Score Rating</div>
                      <div className="text-2xl font-extrabold text-emerald-400">89/100</div>
                    </div>
                    <div className="w-9 h-9 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Sample Claim Strip */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                  <div className="text-slate-400 font-semibold mb-1">Source Credibility</div>
                  <div className="text-emerald-400 font-bold text-sm">97% • High Trust</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">NASA & Nature Registry</div>
                </div>
                <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                  <div className="text-slate-400 font-semibold mb-1">Claim Consistency</div>
                  <div className="text-cyan-400 font-bold text-sm">94% • Fully Supported</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">3 of 3 Claims Verified</div>
                </div>
                <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
                  <div className="text-slate-400 font-semibold mb-1">Linguistic Cleanliness</div>
                  <div className="text-blue-400 font-bold text-sm">98% • Objective</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Zero Clickbait Signals</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. HOW IT WORKS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-widest text-cyan-400">Step-by-Step Architecture</h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-white">How TruthLens AI Analyzes Content</h3>
          <p className="text-slate-400 text-sm max-w-2xl mx-auto">
            From raw multimodal ingestion to fine-grained semantic claim verification and mathematical trust score synthesis.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            {
              step: '01',
              title: 'Ingestion & OCR',
              desc: 'Submit text snippets, live article URLs, documents (PDF/DOCX), or image screenshots with optical text extraction.',
              icon: FileText,
              color: 'text-cyan-400',
              bg: 'bg-cyan-500/10'
            },
            {
              step: '02',
              title: 'NLP Claim Extraction',
              desc: 'Rule-based and semantic NLP decompose paragraphs into distinct verifiable factual propositions and statistical claims.',
              icon: Cpu,
              color: 'text-blue-400',
              bg: 'bg-blue-500/10'
            },
            {
              step: '03',
              title: 'Cross-Source Retrieval',
              desc: 'Claims are cross-checked against peer-reviewed registries, verified knowledge databases, and authoritative news wires.',
              icon: Globe,
              color: 'text-indigo-400',
              bg: 'bg-indigo-500/10'
            },
            {
              step: '04',
              title: 'Explainable Trust Score',
              desc: 'A weighted scoring engine computes a transparent 0–100 Trust Score with comprehensive claim-by-claim justifications.',
              icon: BarChart3,
              color: 'text-emerald-400',
              bg: 'bg-emerald-500/10'
            }
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="relative p-6 rounded-2xl glass-panel border border-slate-800 hover:border-slate-700 transition duration-300 space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className={`p-3 rounded-xl ${item.bg} ${item.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-2xl font-mono font-black text-slate-700">
                    {item.step}
                  </span>
                </div>
                <h4 className="text-lg font-bold text-white">{item.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. KEY FEATURES GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-widest text-cyan-400">Core Capabilities</h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-white">Full-Spectrum Misinformation Detection</h3>
          <p className="text-slate-400 text-sm max-w-2xl mx-auto">
            Engineered with academic rigor, incorporating multi-dimensional fact-checking and emotional manipulation forensics.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400">
              <Zap className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white">Claim-by-Claim Verification</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every factual assertion is evaluated individually with explicit verdicts: <span className="text-emerald-400 font-medium">Supported</span>, <span className="text-rose-400 font-medium">Contradicted</span>, <span className="text-amber-400 font-medium">Needs Verification</span>, or <span className="text-cyan-400 font-medium">Partially Supported</span>.
            </p>
          </div>

          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white">Linguistic & Clickbait Forensics</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Quantifies sensationalism, urgency rhetoric, fear-mongering lexical markers, and exaggerated clickbait headlines to flag manipulative narratives.
            </p>
          </div>

          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white">Domain & Source Reputation</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Assesses domain authority, author bylines, peer-review presence, DOI references, and citation completeness using curated authority databases.
            </p>
          </div>

          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
              <BarChart3 className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white">Transparent Weighted Formula</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              No black-box obscurity. The Trust Score is calculated using 6 modular components with fully customizable parameter weightings.
            </p>
          </div>

          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400">
              <Layers className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white">Multimodal Input Ingestion</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Seamlessly analyze pasted text, news URLs, PDF research papers, DOCX briefs, and infographic screenshots in one unified interface.
            </p>
          </div>

          <div className="p-6 rounded-2xl glass-panel border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-white">Academic & Research Alignment</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Built for college capstones, research presentations, and AI hackathons, featuring a complete academic methodology and BibTeX generator.
            </p>
          </div>
        </div>
      </section>

      {/* 4. STATISTICS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-panel-glow rounded-3xl p-8 sm:p-12 bg-slate-900 border border-slate-700 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-3xl sm:text-4xl font-extrabold text-cyan-400 font-mono">94.8%</div>
            <div className="text-xs text-slate-400 mt-1 font-medium">Claim Verification Accuracy</div>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-extrabold text-emerald-400 font-mono">&lt; 350ms</div>
            <div className="text-xs text-slate-400 mt-1 font-medium">Average Detection Latency</div>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-extrabold text-blue-400 font-mono">10,000+</div>
            <div className="text-xs text-slate-400 mt-1 font-medium">Fact-Check Knowledge Triples</div>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-extrabold text-indigo-400 font-mono">100%</div>
            <div className="text-xs text-slate-400 mt-1 font-medium">Explainable XAI Output</div>
          </div>
        </div>
      </section>

      {/* 5. PRESET DEMO SCENARIOS PREVIEW */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xs font-bold uppercase tracking-widest text-cyan-400">Interactive Demos</h2>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white">Try Preloaded Benchmark Cases</h3>
          </div>
          <button
            onClick={() => onNavigate('analyze')}
            className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            Explore custom input <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              id: 'trustworthy',
              title: 'NASA Space Telescope Discovery',
              type: 'Scientific Release',
              verdict: 'Highly Trustworthy',
              score: '89/100',
              badgeColor: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
            },
            {
              id: 'misleading',
              title: 'Lemon Water Cancer Miracle',
              type: 'Health Misinformation',
              verdict: 'Likely Misleading',
              score: '31/100',
              badgeColor: 'text-orange-400 bg-orange-500/10 border-orange-500/30'
            },
            {
              id: 'false',
              title: '5G Microchip Vaccine Leak',
              type: 'Conspiracy Rumor',
              verdict: 'Likely False',
              score: '14/100',
              badgeColor: 'text-rose-400 bg-rose-500/10 border-rose-500/30'
            },
            {
              id: 'clickbait',
              title: 'Shocking 48h Belly Fat Secret',
              type: 'Sensational Clickbait',
              verdict: 'Likely Misleading',
              score: '24/100',
              badgeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30'
            }
          ].map((demo) => (
            <div
              key={demo.id}
              onClick={() => onSelectDemo(demo.id)}
              className="p-5 rounded-xl glass-panel border border-slate-800 hover:border-cyan-500/50 hover:bg-slate-800/60 cursor-pointer transition flex flex-col justify-between group"
            >
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                  {demo.type}
                </span>
                <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition">
                  {demo.title}
                </h4>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${demo.badgeColor}`}>
                  {demo.verdict}
                </span>
                <span className="text-xs font-mono font-bold text-slate-300">
                  {demo.score}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. CALL TO ACTION BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-blue-900/60 via-slate-900 to-cyan-950/60 border border-cyan-500/30 text-center space-y-6">
          <h3 className="text-2xl sm:text-4xl font-extrabold text-white">
            Ready to Verify Information with Data-Driven AI?
          </h3>
          <p className="text-slate-300 text-sm max-w-xl mx-auto">
            Test any news article, social media claim, uploaded document, or web URL with zero setup required.
          </p>
          <button
            onClick={() => onNavigate('analyze')}
            className="px-8 py-3 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-400/20 inline-flex items-center gap-2 transition"
          >
            <Sparkles className="w-4 h-4" />
            <span>Launch Analysis Studio</span>
          </button>
        </div>
      </section>
    </div>
  );
};
