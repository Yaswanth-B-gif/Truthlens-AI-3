export type ContentType = 'text' | 'url' | 'document' | 'image' | 'demo';

export type ClassificationType = 
  | 'Highly Trustworthy'
  | 'Mostly Trustworthy'
  | 'Needs Verification'
  | 'Likely Misleading'
  | 'Likely False';

export type ClaimVerdict = 
  | 'Supported'
  | 'Contradicted'
  | 'Unverified'
  | 'Partially Supported';

export type RiskLevel = 'Low' | 'Moderate' | 'Elevated' | 'High' | 'Critical';

export interface User {
  id: number;
  name: string;
  email: string;
  created_at: string;
}

export interface Claim {
  id?: number;
  claim_text: string;
  verdict: ClaimVerdict;
  confidence: number;
  evidence: string;
  category?: string;
}

export interface Source {
  id?: number;
  title: string;
  url?: string;
  credibility: number;
  source_type: 'supporting' | 'contradicting' | 'reference';
  domain?: string;
  stance?: string;
}

export interface ScoreBreakdown {
  source_credibility: number;
  evidence_strength: number;
  claim_consistency: number;
  cross_source_agreement: number;
  language_manipulation_cleanliness: number;
  context_completeness: number;
}

export interface EmotionalIntensity {
  fear: number;
  anger: number;
  urgency: number;
  sensationalism: number;
}

export interface SentimentAnalysis {
  label: 'Positive' | 'Negative' | 'Neutral';
  positive: number;
  negative: number;
  neutral: number;
  compound: number;
}

export interface LinguisticMetrics {
  sentiment: SentimentAnalysis;
  emotional_intensity: EmotionalIntensity;
  clickbait_score: number;
  hyperbole_count: number;
  readability_level: string;
  flesch_score?: number;
  word_count: number;
  manipulation_cleanliness_score?: number;
}

export interface AnalysisResult {
  id: string;
  user_id?: number | null;
  content_title?: string;
  content: string;
  content_type: ContentType;
  trust_score: number;
  classification: ClassificationType;
  confidence: number;
  risk_level: RiskLevel;
  explanation: string;
  score_breakdown?: ScoreBreakdown;
  linguistic_metrics?: LinguisticMetrics;
  claims: Claim[];
  sources: Source[];
  is_demo?: boolean;
  created_at: string;
}

export interface AnalysisSummary {
  id: string;
  user_id?: number | null;
  content_title?: string;
  content_type: ContentType;
  trust_score: number;
  classification: ClassificationType;
  confidence: number;
  risk_level: RiskLevel;
  is_demo: boolean;
  created_at: string;
}

export interface ScoreDistributionBucket {
  range: string;
  count: number;
  label: string;
}

export interface ClassificationChartItem {
  name: string;
  value: number;
  color: string;
}

export interface DashboardStats {
  total_analyses: number;
  trustworthy_count: number;
  misleading_count: number;
  false_count: number;
  needs_verification_count: number;
  average_trust_score: number;
  score_distribution: ScoreDistributionBucket[];
  classification_distribution: ClassificationChartItem[];
  recent_analyses: AnalysisSummary[];
}

export interface FeedbackSubmission {
  analysis_id: string;
  rating: number;
  comment?: string;
}
