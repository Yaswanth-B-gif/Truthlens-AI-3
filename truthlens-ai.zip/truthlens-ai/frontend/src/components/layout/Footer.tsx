import React from 'react';
import { BrandLogo } from '../ui/BrandLogo';
import { ShieldCheck, Sparkles, BookOpen, ExternalLink, Code2 } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="border-t border-slate-800/80 bg-slate-950 text-slate-400 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Col 1: Brand & Overview */}
        <div className="space-y-4 md:col-span-1">
          <BrandLogo size="md" />
          <p className="text-xs text-slate-400 leading-relaxed">
            TruthLens AI is an advanced data-driven platform combining multi-stage natural language processing, automated claim extraction, and cross-source verification to evaluate digital content credibility.
          </p>
          <div className="flex items-center gap-2 text-[11px] text-cyan-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            AI Inference Engine v1.0 • Online
          </div>
        </div>

        {/* Col 2: Navigation */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">Platform Navigation</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => onNavigate('landing')} className="hover:text-cyan-400 transition">
                Platform Overview
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('analyze')} className="hover:text-cyan-400 transition">
                Live Content Analyzer
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('dashboard')} className="hover:text-cyan-400 transition">
                Analytics & Verification Dashboard
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('history')} className="hover:text-cyan-400 transition">
                Inspection History Log
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('research')} className="hover:text-cyan-400 transition">
                Methodology & System Architecture
              </button>
            </li>
          </ul>
        </div>

        {/* Col 3: Research & Tech Stack */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">Academic & Tech Stack</h4>
          <ul className="space-y-2 text-xs">
            <li className="flex items-center gap-1.5 text-slate-300">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
              FastAPI & Modular NLP Pipeline
            </li>
            <li className="flex items-center gap-1.5 text-slate-300">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
              Claim-Level Semantic Verification
            </li>
            <li className="flex items-center gap-1.5 text-slate-300">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
              React 18 + TypeScript + Tailwind
            </li>
            <li className="flex items-center gap-1.5 text-slate-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              SQLAlchemy Multi-Tenant Storage
            </li>
          </ul>
        </div>

        {/* Col 4: Mandatory Safety Disclaimer */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            AI Safety & Accuracy Notice
          </h4>
          <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-[11px] leading-relaxed text-amber-200/90">
            <strong>TruthLens AI</strong> provides an automated assessment and should not be considered an absolute fact-checking authority. Always verify important information using reliable primary sources.
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="max-w-7xl mx-auto mt-8 pt-6 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
        <div>
          © {new Date().getFullYear()} TruthLens AI Research Group. Academic Prototype & Fact Intelligence System.
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('research')} className="hover:text-slate-300 flex items-center gap-1">
            <BookOpen className="w-3.5 h-3.5" /> Research Paper / Documentation
          </button>
        </div>
      </div>
    </footer>
  );
};
