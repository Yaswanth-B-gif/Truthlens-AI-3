import React from 'react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ size = 'md', showText = true }) => {
  const sizeClasses = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
  };

  const textClasses = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl',
  };

  return (
    <div className="flex items-center gap-2.5 group cursor-pointer">
      <div className={`relative ${sizeClasses[size]} flex items-center justify-center`}>
        {/* Glowing aura */}
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 rounded-xl blur-sm opacity-70 group-hover:opacity-100 transition duration-300"></div>
        
        {/* Modern Vector SVG: Shield + Eye + AI Data Node */}
        <svg
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="relative z-10 w-full h-full p-1"
        >
          {/* Shield Base */}
          <path
            d="M24 4L8 10V22C8 31.5 14.8 40.3 24 44C33.2 40.3 40 31.5 40 22V10L24 4Z"
            fill="url(#shield_grad)"
            stroke="#38BDF8"
            strokeWidth="1.5"
          />
          {/* Eye Outline */}
          <path
            d="M14 24C16.5 19.5 20 17 24 17C28 17 31.5 19.5 34 24C31.5 28.5 28 31 24 31C20 31 16.5 28.5 14 24Z"
            stroke="#FFFFFF"
            strokeWidth="1.75"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Iris & AI Core Pupil */}
          <circle cx="24" cy="24" r="4.5" fill="#38BDF8" />
          <circle cx="24" cy="24" r="2" fill="#FFFFFF" />
          {/* AI Neural Pulses */}
          <circle cx="24" cy="11" r="1.5" fill="#38BDF8" />
          <circle cx="16" cy="33" r="1.25" fill="#38BDF8" />
          <circle cx="32" cy="33" r="1.25" fill="#38BDF8" />
          <defs>
            <linearGradient id="shield_grad" x1="8" y1="4" x2="40" y2="44" gradientUnits="userSpaceOnUse">
              <stop stopColor="#0B132B" />
              <stop offset="1" stopColor="#1E3A8A" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <span className={`font-extrabold tracking-tight bg-gradient-to-r from-white via-cyan-200 to-blue-400 bg-clip-text text-transparent ${textClasses[size]}`}>
            TruthLens<span className="text-cyan-400 font-semibold ml-0.5">AI</span>
          </span>
          {size === 'lg' && (
            <span className="text-[10px] tracking-widest uppercase text-slate-400 font-medium">
              Data-Driven Fact Intelligence
            </span>
          )}
        </div>
      )}
    </div>
  );
};
