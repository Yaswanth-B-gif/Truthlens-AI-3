import React from 'react';
import { ClassificationType, RiskLevel } from '../../types';

interface ScoreGaugeProps {
  score: number;
  classification: ClassificationType;
  confidence: number;
  riskLevel: RiskLevel;
  size?: number;
}

export const ScoreGauge: React.FC<ScoreGaugeProps> = ({
  score,
  classification,
  confidence,
  riskLevel,
  size = 220,
}) => {
  // Score color determinations
  const getColor = (s: number) => {
    if (s >= 80) return { stroke: '#10B981', text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30' };
    if (s >= 60) return { stroke: '#06B6D4', text: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/30' };
    if (s >= 40) return { stroke: '#F59E0B', text: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30' };
    if (s >= 20) return { stroke: '#F97316', text: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/30' };
    return { stroke: '#EF4444', text: 'text-rose-500', bg: 'bg-rose-500/10', border: 'border-rose-500/30' };
  };

  const colorScheme = getColor(score);
  
  // SVG circular arc calculations
  const strokeWidth = 14;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center p-4">
      <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
        {/* Glow backdrop */}
        <div 
          className="absolute inset-4 rounded-full blur-xl opacity-30"
          style={{ backgroundColor: colorScheme.stroke }}
        ></div>

        <svg width={size} height={size} className="transform -rotate-90">
          {/* Background track circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth={strokeWidth}
            fill="transparent"
            className="text-slate-800/80 dark:text-slate-800"
          />
          {/* Animated active score circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={colorScheme.stroke}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            fill="transparent"
            className="transition-all duration-1000 ease-out"
          />
        </svg>

        {/* Center score details */}
        <div className="absolute flex flex-col items-center justify-center text-center">
          <span className="text-xs uppercase tracking-widest font-semibold text-slate-400">
            Trust Score
          </span>
          <div className="flex items-baseline">
            <span className={`text-5xl font-extrabold tracking-tight ${colorScheme.text}`}>
              {Math.round(score)}
            </span>
            <span className="text-xl font-medium text-slate-400 ml-1">/100</span>
          </div>
          <span className="text-[11px] font-medium text-slate-400 mt-0.5">
            Confidence: <strong className="text-slate-200">{Math.round(confidence)}%</strong>
          </span>
        </div>
      </div>

      {/* Badges footer */}
      <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
        <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${colorScheme.bg} ${colorScheme.border} ${colorScheme.text}`}>
          {classification}
        </span>
        <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-800/80 border border-slate-700 text-slate-300">
          Risk: <strong className={riskLevel === 'Low' ? 'text-emerald-400' : riskLevel === 'Moderate' ? 'text-amber-400' : 'text-rose-400'}>{riskLevel}</strong>
        </span>
      </div>
    </div>
  );
};
