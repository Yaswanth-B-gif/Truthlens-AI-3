import React, { useState } from 'react';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { LandingPage } from './pages/LandingPage';
import { AnalyzePage } from './pages/AnalyzePage';
import { ResultsPage } from './pages/ResultsPage';
import { DashboardPage } from './pages/DashboardPage';
import { HistoryPage } from './pages/HistoryPage';
import { ResearchPage } from './pages/ResearchPage';
import { AuthModal } from './components/auth/AuthModal';
import { AnalysisResult } from './types';
import { api } from './services/api';

export const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<string>('landing');
  const [currentResult, setCurrentResult] = useState<AnalysisResult | null>(null);
  const [presetScenario, setPresetScenario] = useState<string | null>(null);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectDemo = (scenario: string) => {
    setPresetScenario(scenario);
    setCurrentPage('analyze');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAnalysisComplete = (result: AnalysisResult) => {
    setCurrentResult(result);
    setPresetScenario(null);
    setCurrentPage('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewAnalysis = async (id: string) => {
    try {
      const full = await api.history.getById(id);
      setCurrentResult(full);
      setCurrentPage('results');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) {
      console.error('Failed to load analysis:', e);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 selection:bg-cyan-500 selection:text-white transition-colors duration-200">
      <Navbar currentPage={currentPage} onNavigate={handleNavigate} />
      
      <main className="flex-1">
        {currentPage === 'landing' && (
          <LandingPage onNavigate={handleNavigate} onSelectDemo={handleSelectDemo} />
        )}
        {currentPage === 'analyze' && (
          <AnalyzePage 
            onAnalysisComplete={handleAnalysisComplete} 
            presetScenario={presetScenario} 
          />
        )}
        {currentPage === 'results' && currentResult && (
          <ResultsPage 
            result={currentResult} 
            onBack={() => handleNavigate('analyze')} 
          />
        )}
        {currentPage === 'dashboard' && (
          <DashboardPage 
            onViewAnalysis={handleViewAnalysis} 
            onNavigate={handleNavigate} 
          />
        )}
        {currentPage === 'history' && (
          <HistoryPage 
            onViewAnalysis={handleViewAnalysis} 
            onNavigate={handleNavigate} 
          />
        )}
        {currentPage === 'research' && (
          <ResearchPage />
        )}
      </main>

      <Footer onNavigate={handleNavigate} />
      <AuthModal />
    </div>
  );
};
